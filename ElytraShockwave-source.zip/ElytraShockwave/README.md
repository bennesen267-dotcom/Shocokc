# Elytra Shockwave (Fabric 1.20.1)

Client-side Fabric mod that shows a sonic-boom particle burst in front of any visible player who is elytra-flying faster than a configurable threshold. It does not modify server gameplay.

## Features
- Minecraft 1.20.1 + Fabric
- Default menu key: Right Shift
- Change the menu key under **Options → Controls → Key Binds**
- In the mod menu, set the minimum speed from **5 to 100 blocks/second**
- Checks both your player and other visible players
- Lightweight: only emits particles while an elytra-flying player exceeds the speed threshold, with an 8-tick per-player cooldown

## Build on GitHub (phone-friendly)
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root (the `.github` folder must be included).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build Fabric Mod** with **Run workflow**, or push a commit to `main`/`master`.
5. Open the completed workflow run and download the `elytra-shockwave` artifact. Extract it to get the `.jar`.
6. Put the `.jar` in `.minecraft/mods` alongside Fabric API, then launch Minecraft 1.20.1 Fabric.

## Build locally
Requires JDK 17 and Gradle 8.x. Run `gradle build`; output is in `build/libs/`.

## Notes
- The speed threshold and key selection currently apply for the current game session; this starter project does not save settings to a config file.
- Effects are client-side particles. Other players must be visible to your client for their effects to be shown.
