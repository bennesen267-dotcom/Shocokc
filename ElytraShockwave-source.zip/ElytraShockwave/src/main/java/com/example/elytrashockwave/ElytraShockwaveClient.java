package com.example.elytrashockwave;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ElytraShockwaveClient implements ClientModInitializer {
    public static final String MOD_ID = "elytrashockwave";
    private static KeyBinding openMenuKey;
    private static int minimumSpeed = 30; // blocks per second
    private static int particleCooldown = 8; // ticks between bursts per player
    private static final Map<UUID, Long> LAST_BURST = new HashMap<>();
    private static long clientTick = 0;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elytrashockwave.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.elytrashockwave"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            clientTick++;
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ShockwaveConfigScreen());
                }
            }
            tickPlayers(client);
        });
    }

    private static void tickPlayers(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            LAST_BURST.clear();
            return;
        }

        for (PlayerEntity player : client.world.getPlayers()) {
            if (!player.isFallFlying()) continue;

            double speedBlocksPerSecond = player.getVelocity().length() * 20.0;
            if (speedBlocksPerSecond < minimumSpeed) continue;

            UUID id = player.getUuid();
            long last = LAST_BURST.getOrDefault(id, Long.MIN_VALUE / 2);
            if (clientTick - last < particleCooldown) continue;
            LAST_BURST.put(id, clientTick);

            // Put the burst just ahead of the flying player's facing direction.
            Vec3d forward = player.getRotationVec(1.0F).normalize();
            Vec3d center = player.getPos()
                    .add(0.0, player.getHeight() * 0.55, 0.0)
                    .add(forward.multiply(1.8));

            // Sonic-boom particles are client-side visual effects; no server changes needed.
            client.world.addParticle(ParticleTypes.SONIC_BOOM,
                    center.x, center.y, center.z,
                    forward.x * 0.12, forward.y * 0.06, forward.z * 0.12);

            // Small cloud accents make the burst read more like a pressure wave.
            Vec3d side = new Vec3d(-forward.z, 0.0, forward.x).normalize();
            for (int sign : new int[]{-1, 1}) {
                Vec3d point = center.add(side.multiply(sign * 0.45));
                client.world.addParticle(ParticleTypes.CLOUD,
                        point.x, point.y, point.z,
                        forward.x * 0.08, forward.y * 0.03, forward.z * 0.08);
            }
        }

        // Avoid keeping stale entries for players who left the world.
        if (LAST_BURST.size() > 128) LAST_BURST.clear();
    }

    public static int getMinimumSpeed() {
        return minimumSpeed;
    }

    public static void setMinimumSpeed(int speed) {
        minimumSpeed = Math.max(5, Math.min(100, speed));
    }
}
