package com.example.elytrashockwave;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class ShockwaveConfigScreen extends Screen {
    private SpeedSlider speedSlider;

    public ShockwaveConfigScreen() {
        super(Text.translatable("screen.elytrashockwave.title"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        speedSlider = new SpeedSlider(centerX - 105, centerY - 10, 210, 20,
                ElytraShockwaveClient.getMinimumSpeed());
        addDrawableChild(speedSlider);

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> close())
                .dimensions(centerX - 60, centerY + 28, 120, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 65, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.translatable("screen.elytrashockwave.description"), width / 2, height / 2 - 42, 0xCFCFCF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.translatable("screen.elytrashockwave.key_hint"), width / 2, height / 2 + 58, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static final class SpeedSlider extends SliderWidget {
        private SpeedSlider(int x, int y, int width, int height, int speed) {
            super(x, y, width, height, Text.empty(), (speed - 5) / 95.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            int speed = getSpeed();
            setMessage(Text.translatable("screen.elytrashockwave.minimum_speed", speed));
        }

        @Override
        protected void applyValue() {
            ElytraShockwaveClient.setMinimumSpeed(getSpeed());
        }

        private int getSpeed() {
            return 5 + (int) Math.round(value * 95.0);
        }
    }
}
